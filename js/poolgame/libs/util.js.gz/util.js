function char(character)
{
    return character.charCodeAt(0);
}