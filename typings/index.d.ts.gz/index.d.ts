/// <reference path="globals/stats.js/index.d.ts" />
/// <reference path="globals/three-orbitcontrols/index.d.ts" />
/// <reference path="globals/three/index.d.ts" />
/// <reference path="modules/dat-gui/index.d.ts" />
